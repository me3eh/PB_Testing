class ActionName:
    def __init__(self, text, attribute_needed=False):
        self.text = text
        self.attribute_needed = attribute_needed
