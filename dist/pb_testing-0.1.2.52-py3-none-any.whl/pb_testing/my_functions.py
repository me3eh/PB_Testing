def adding_two_numbers(first_number, second_number):
    return int(first_number) + int(second_number)
