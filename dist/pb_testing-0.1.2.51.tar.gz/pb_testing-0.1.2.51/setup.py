from setuptools import find_packages, setup
# import os
# lib_folder = os.path.dirname(os.path.realpath(__file__))
# requirement_path = lib_folder + '/requirements.txt'
# install_requires = [] # Here we'll get: ["gunicorn", "docutils>=0.3", "lxml==0.5a7"]
# if os.path.isfile(requirement_path):
#     with open(requirement_path) as f:
#         install_requires = f.read().splitlines()
setup(
    name='pb_testing',
    packages=find_packages(include=['pb_testing']),
    version='0.1.2.51',
    scripts=['bin/prepare', 'bin/scan_for_urls', 'bin/create-scenario', 'bin/extra_modules_for_pb_testing.py',
                'bin/pb_configuration', 'bin/create-scenario-gui', 'bin/step_creator'],
    description='Library for bdd testing',
    author='Me',
    license='MIT',
    setup_requires=['pytest-runner'],
    tests_require=['pytest==4.4.1'],
    test_suite='tests',
    include_package_data=True
)