#!python
# importing that, to have access to src in commands
import sys
import os
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + "/../src")
