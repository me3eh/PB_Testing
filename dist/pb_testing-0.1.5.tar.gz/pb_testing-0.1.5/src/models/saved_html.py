class SavedHtml:
    def __init__(self, link, username, password, html):
        self.link = link
        self.username = username
        self.password = password
        self.html = html
