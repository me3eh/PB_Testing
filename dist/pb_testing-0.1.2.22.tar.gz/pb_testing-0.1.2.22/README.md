
Library for BDD testing. Work in Progress. Have fun using this library.
This command will initialize needed directories for testing with our project
Pushing to repo

```bash
create-dirs
```

To create script file, you will need to type command below
```bash
create-scenario
```
After that the menu will apear. Hopefully everything will be understandable from this point

Little tips:
creating fixtures

```bash
python3 manage.py dumpdata auth.User --indent 4 > users.json
```

and after that to run server with date from fixtures

```bash
python3 manage.py testserver users.json groups.json --addrport 7000 & PID=$
```
<div style="background-image: linear-gradient(to left, violet, indigo, blue, green, yellow, orange, red); text-align: center; color: black;">
<h1 style="margin-bottom: 20px">Little tips for building python package<br/>( probably only me)</h1>
</div>
Building dist files for python pypi

```bash
python3 -m build
```
<br/>

Pushing files for python pypi

```bash
python3 -m twine upload --repository testpypi dist/*
```

Points to do:
- [ ] add class and id into file resources_for_testing
- [ ] decide if project need TUI (terminal interface) or GUI (graphical interface)
- [ ] think about urls with parameters (what to do with them and how to extract classes and ids from them after picking attributes)
