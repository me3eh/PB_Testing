class SavedActions:
    def __init__(self, bdd_attribute, action_name):
        self.bdd_attribute = bdd_attribute
        self.action_name = action_name
