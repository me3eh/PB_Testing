

Library for BDD testing. Work in Progress. Have fun using this library.
This command will initialize needed directories for testing with our project

```bash
create-dirs
```

In order to effectively use this library, you need
```terminal

```